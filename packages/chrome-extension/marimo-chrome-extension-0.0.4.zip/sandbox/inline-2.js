
      Object.defineProperty(window, "__MARIMO_MOUNT_CONFIG__", {
        value: Object.freeze({
            "filename": "notebook.py",
            "cwd": "",
            "lspWorkspace": null,
            "mode": "edit",
            "version": "0.25.2+chromeext",
            "serverToken": "unused",
            "config": {"ai": {"allow_provider_config": true, "custom_providers": {}, "enabled": true, "max_tokens": null, "mode": "ask", "models": {"autocomplete_model": null, "chat_model": null, "custom_models": [], "displayed_models": [], "edit_model": null}, "rules": ""}, "cache": {"loader": "lazy", "store": null, "verification": "off"}, "completion": {"activate_on_typing": true, "auto_close_pairs": true, "copilot": false, "signature_hint_on_typing": false}, "datasources": {}, "diagnostics": {"sql_linter": true}, "display": {"cell_output": "below", "code_editor_font_size": 14, "code_lens": true, "dataframes": "rich", "default_table_max_columns": 50, "default_table_page_size": 10, "default_width": "medium", "reference_highlighting": true, "theme": "light"}, "experimental": {"debugger": false, "execution_type": "relaxed", "isolate_apps": false, "line_timing": false}, "file_browser": null, "formatting": {"infer_types": "off", "line_length": 79}, "keymap": {"overrides": {}, "preset": "default"}, "language_servers": {"pylsp": {"enable_flake8": false, "enable_mypy": true, "enable_pydocstyle": false, "enable_pyflakes": false, "enable_pylint": false, "enable_ruff": true, "enabled": false}}, "lint": {"ignore": [], "select": []}, "mcp": {"mcpServers": {}, "presets": []}, "package_management": {"manager": "pip"}, "runtime": {"auto_instantiate": true, "auto_reload": "off", "cache_cells": false, "default_auto_download": [], "default_csv_encoding": "utf-8", "default_sql_output": "auto", "on_cell_change": "autorun", "output_max_bytes": 8000000, "pin_modules": true, "pythonpath": [], "reactive_tests": true, "serve_cached_sessions_in_apps": false, "show_tracebacks": false, "std_stream_max_bytes": 1000000, "watcher_on_save": "lazy"}, "save": {"autosave": "off", "autosave_delay": 1000, "format_on_save": false}, "server": {"allow_origins": [], "base_url": "", "browser": "default", "disable_file_downloads": false, "follow_symlink": false, "headless": false, "host": "127.0.0.1", "include_code": false, "port": null, "proxy": null, "redirect_console_to_browser": false, "session_cookie_partitioned": false, "session_cookie_secure": false, "session_secret": null, "skew_protection": true, "skip_update_check": false, "timeout": null, "token_password": null, "token_password_file": null, "watch": false}, "sharing": null, "signing": {"private_key_path": null, "trusted_signers": {}}, "snippets": {"custom_paths": [], "include_default_snippets": true}, "venv": {"path": null, "writable": false}},
            "configOverrides": {},
            "appConfig": {"sql_output": "auto", "width": "compact"},
            "layout": null,
            "view": {"showAppCode": false},
            "notebook": null,
            "session": null,
            "runtimeConfig": null,
            "pairConfig": {"command": "uvx marimo@latest", "hostEnabled": true, "templates": {"notebook": "Notebook: {notebook} (use --session for execution)\n", "prompt": "Pair with me on this running marimo notebook.\n\nURL: {url}\n{notebook}{session}\nRun `{command} pair --help` first.\nUse `{command}` for all marimo commands.{authentication}", "session": "Session: {session}\n", "token": "\n\nFor explicit server authentication, set `export MARIMO_TOKEN={token}` in the shell that runs marimo.", "token_file": "\n\nFor explicit server authentication, pass `--token-file {token_file}`."}}
        }),
        writable: false,
        configurable: false,
      });
    